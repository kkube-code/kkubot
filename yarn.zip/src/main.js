import {Client, Events, GatewayIntentBits, IntentsBitField} from "discord.js";
import dotenv from "dotenv";
import vueinit from '@/core/vue'
import {loadCommands, loadEvents} from '@/core/loader.js'
import { useAppStore } from "./store/app";


    vueinit();
    dotenv.config();
    loadCommands();
    
    const client = new Client({intents:[
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.DirectMessages,
        IntentsBitField.Flags.MessageContent
      ]});
    const appStore = useAppStore();
    appStore.client = client;
    
    loadEvents();

    

    
    
    client.login(process.env.TOKEN);

