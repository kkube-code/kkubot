import { Events } from "discord.js";

export const event = {
    name: Events.MessageCreate,
}

export const action = async (msg) => {
    if(msg.content === "ww"){//當檢測到訊息為hi的時候
        
        await msg.channel.send(`<@978937687958491146>`);
    }
}